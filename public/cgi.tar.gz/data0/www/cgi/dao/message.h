#include "../basic.h"

#ifndef __dao_message_h
#define __dao_message_h

#include "../util/db.h"

#endif
