#include "basic.h"

#ifndef __cgi_h
#define __cgi_h

#include "http/http.h"
#include "http/response.h"
#include "http/route.h"

#endif
