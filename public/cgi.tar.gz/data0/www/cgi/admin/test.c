#include "test.h"

void adminTestHello(){
}

