#include <stdio.h>
#include <fcgi_stdio.h>


#ifndef __admin_test_h
#define __admin_test_h
extern void adminTestHello();


#endif
