#include "../basic.h"

#ifndef __default_main_h
#define __default_main_h

#include "../dao/article.h"
#include "../http/request.h"
#include "../util/tools.h"
/**
 * @TODO 留言板首页展示
 * @return void
 * @author zhouwei 2013-8-15
 */
extern void defaultMainHtml();

/**
 * @TODO 提交留言
 * @return void
 * @author zhouwei 2013-8-15
 */
extern void defaultSubmitMessage();


#endif
